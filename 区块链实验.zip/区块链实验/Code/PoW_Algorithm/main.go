package main

import (
	"PoW_Algorithm/Block"
	"PoW_Algorithm/BlockChain"
	"fmt"
	"os"
	"strconv"
)

func main() {
	/**for i, v := range os.Args {
		fmt.Println(i, v)
	}**/
	var diff int
	diff, _ = strconv.Atoi(os.Args[1]) //获取初始化难度
	fmt.Printf("initial Diff: %d\n", diff)
	var headBlock = Block.GenerateFirstBlock("genesisBlock") //创建第一个创世区块
	fmt.Println("genesisBlock has been generated successful:")
	fmt.Printf("Index:%d TimeStamp:%s Diff:%d Nonce:%d HashCode:%s\n", headBlock.Index, headBlock.TimeStamp, headBlock.Diff, headBlock.Nonce, headBlock.HashCode)

	var blockChain = BlockChain.CreatHeadNode(&headBlock) //初始化区块链
	fmt.Println("BlockChain initialized successfully!")

	fmt.Println("**********Nodes start competing the 2 block:**********") //节点开始竞争下一个区块的创建权
	var nextBlock = Block.GenerateNextBlock("2 block", headBlock, diff)   //创建下一个区块，需要满足工作量要求
	fmt.Printf("Index:%d TimeStamp:%s Diff:%d Nonce:%d HashCode:%s\n", nextBlock.Index, nextBlock.TimeStamp, nextBlock.Diff, nextBlock.Nonce, nextBlock.HashCode)
	fmt.Println("**********the 2 Block has been generated successful:**********")

	BlockChain.AddNode(&nextBlock, blockChain) //新增区块，使用链表结构
	fmt.Println("blockChain add the second new Node successfully!")
	var blockName string
	var prevBlock = nextBlock
	for i := 3; i < 7; i++ {
		diff *= 2 //难度依次翻倍增加
		//diff += 2 //难度依次递增增加
		blockName = strconv.Itoa(i) + " block"
		fmt.Println("**********Nodes start competing the " + strconv.Itoa(i) + " block:**********")
		nextBlock = Block.GenerateNextBlock(blockName, prevBlock, diff)
		fmt.Printf("Index:%d TimeStamp:%s Diff:%d Nonce:%d HashCode:%s\n", nextBlock.Index, nextBlock.TimeStamp, nextBlock.Diff, nextBlock.Nonce, nextBlock.HashCode)
		fmt.Println("**********the " + strconv.Itoa(i) + " block has been generated successful:**********")
		BlockChain.AddNode(&nextBlock, blockChain)
		prevBlock = nextBlock
	}

	BlockChain.ShowBlockChain(blockChain) //输出连上所有区块
}
