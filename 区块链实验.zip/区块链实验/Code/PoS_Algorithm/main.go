package main

import (
	"PoS_Algorithm/Block"
	"PoS_Algorithm/Coin"
	"fmt"
	"os"
	"strconv"
	"time"
)

type Params struct {
	dif         int
	MaxProbably int
	MinProbably int
	MaxCoinAge  int
	Minute      int
}

//go run main.go 192.168.1.1 192.168.1.2 2 255 235 10 60
func main() {
	fmt.Println("************read parameters from command begins***********")
	var tmp [5]int //store the params
	var addr1 string
	var addr2 string
	index := 0
	for i, v := range os.Args {
		if i == 1 {
			addr1 = v
		}
		if i == 2 {
			addr2 = v
		}
		if i > 2 {
			tmp[index], _ = strconv.Atoi(v)
			index++
		}
	}
	//fmt.Println(i, v)
	ParamsStruct := Params{
		dif:         tmp[0],
		MaxProbably: tmp[1],
		MinProbably: tmp[2],
		MaxCoinAge:  tmp[3],
		Minute:      tmp[4],
	}
	fmt.Printf("addr1:%s\n", addr1)
	fmt.Printf("addr2:%s\n", addr2)
	fmt.Printf("dif:%d MaxProbably:%d MinProbably:%d MaxCoinAge:%d Minute:%d\n", ParamsStruct.dif, ParamsStruct.MaxProbably, ParamsStruct.MinProbably, ParamsStruct.MaxCoinAge, ParamsStruct.Minute)
	fmt.Println("***************init...******************")
	CoinPool := Coin.GenerateCoinPool(0) //币池初始化
	fmt.Println("***************Generating Blocks begins!******************")
	bc := Block.GenesisBlock("genesisBlock", addr1, ParamsStruct.dif, ParamsStruct.MaxProbably, ParamsStruct.MinProbably, ParamsStruct.MaxCoinAge, ParamsStruct.Minute, CoinPool)
	time.Sleep(1 * time.Second)
	fmt.Println("1 seconds passed......")
	Block.GenerateBlock(bc, "send 1$ to alice", addr1, ParamsStruct.dif, ParamsStruct.MaxProbably, ParamsStruct.MinProbably, ParamsStruct.MaxCoinAge, ParamsStruct.Minute, CoinPool)
	time.Sleep(2 * time.Second)
	fmt.Println("2 seconds passed......")
	Block.GenerateBlock(bc, "send 1$ to alice", addr1, ParamsStruct.dif, ParamsStruct.MaxProbably, ParamsStruct.MinProbably, ParamsStruct.MaxCoinAge, ParamsStruct.Minute, CoinPool)
	time.Sleep(3 * time.Second)
	fmt.Println("3 seconds passed......")
	Block.GenerateBlock(bc, "send 2$ to alice", addr1, ParamsStruct.dif, ParamsStruct.MaxProbably, ParamsStruct.MinProbably, ParamsStruct.MaxCoinAge, ParamsStruct.Minute, CoinPool)
	time.Sleep(2 * time.Second)
	fmt.Println("2 seconds passed......")
	Block.GenerateBlock(bc, "send 3$ to bob", addr2, ParamsStruct.dif, ParamsStruct.MaxProbably, ParamsStruct.MinProbably, ParamsStruct.MaxCoinAge, ParamsStruct.Minute, CoinPool)
	time.Sleep(6 * time.Second)
	fmt.Println("6 seconds passed......")
	Block.GenerateBlock(bc, "send 4$ to bob", addr2, ParamsStruct.dif, ParamsStruct.MaxProbably, ParamsStruct.MinProbably, ParamsStruct.MaxCoinAge, ParamsStruct.Minute, CoinPool)
	fmt.Println("***************Generating Blocks finished!******************")
	Block.Print(bc)
	Coin.PrintCoinPool(CoinPool)
}
