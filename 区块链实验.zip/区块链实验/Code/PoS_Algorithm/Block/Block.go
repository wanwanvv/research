package Block

import (
	"PoS_Algorithm/Coin"
	"bytes"
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"math"
	"math/big"
	"math/rand"
	"time"
)

//定义所需常量
const (
	INT64_MAX = math.MaxInt64
)

//定义区块结构
type Block struct {
	PrevHash  []byte
	Hash      []byte
	Data      string
	Height    int
	Timestamp int
	Coin      Coin.Coin
	Nonce     int
	Dif       int
}

//定义区块结构
type BlockChain struct {
	Blocks []Block
}

//生成创世块,返回区块链头
func GenesisBlock(data string, addr string, dif int, MaxProbably int, MinProbably int, MaxCoinAge int, Minute int, CoinPool *[]Coin.Coin) *BlockChain {
	var bc BlockChain
	rand.Seed(time.Now().UnixNano()) //设置随机数种子
	bc.Blocks = make([]Block, 1)     //区块链增加创世块
	newCoin := Coin.Coin{
		Time:    int(time.Now().Unix()),
		Num:     1 + rand.Intn(5), //随机给出1-5个币
		Address: addr,
	}
	bc.Blocks[0] = Block{
		PrevHash:  []byte(""),
		Data:      data,
		Height:    1,
		Timestamp: int(time.Now().Unix()),
		Coin:      newCoin,
		Nonce:     0,
	}
	start := time.Now()
	bc.Blocks[0].Hash, bc.Blocks[0].Nonce, bc.Blocks[0].Dif = ProofOfStake(addr, bc.Blocks[0], dif, MaxProbably, MinProbably, MaxCoinAge, Minute, CoinPool)
	last := time.Since(start)
	fmt.Printf("index:1 pow time:%s nonce:%d dif:%d", last, bc.Blocks[0].Nonce, bc.Blocks[0].Dif)
	*CoinPool = append(*CoinPool, newCoin)
	return &bc

}

//产生新的区块
func GenerateBlock(bc *BlockChain, data string, addr string, dif int, MaxProbably int, MinProbably int, MaxCoinAge int, Minute int, CoinPool *[]Coin.Coin) {
	rand.Seed(time.Now().UnixNano()) //设置随机数种子
	prevBlock := bc.Blocks[len(bc.Blocks)-1]
	newCoin := Coin.Coin{
		Time:    int(time.Now().Unix()),
		Num:     1 + rand.Intn(5),
		Address: addr,
	}
	b := Block{
		PrevHash:  prevBlock.Hash,
		Data:      data,
		Height:    prevBlock.Height + 1,
		Timestamp: int(time.Now().Unix()),
	}
	start := time.Now()
	b.Hash, b.Nonce, b.Dif = ProofOfStake(addr, b, dif, MaxProbably, MinProbably, MaxCoinAge, Minute, CoinPool)
	last := time.Since(start)
	fmt.Printf("index:%d pos time:%s nonce:%d dif:%d\n", b.Height, last, b.Nonce, b.Dif)
	b.Coin = newCoin
	bc.Blocks = append(bc.Blocks, b)
	*CoinPool = append(*CoinPool, newCoin)
}

//proof of stake algorithm
func ProofOfStake(addr string, b Block, dif int, MaxProbably int, MinProbably int, MaxCoinAge int, Minute int, CoinPool *[]Coin.Coin) ([]byte, int, int) {
	var coinAge int
	var realDif int
	realDif = MinProbably
	curTime := int(time.Now().Unix()) //1970年01月01日00时00分00秒起到此时此刻的秒数
	for k, i := range (*CoinPool) {
		if i.Address == addr && i.Time+MaxCoinAge < curTime {
			//币龄增加，并设置上限
			var curCoinAge int
			if curTime-i.Time < 3*MaxCoinAge {
				curCoinAge = curTime - i.Time
			} else {
				curCoinAge = 3 * MaxCoinAge //上限
			}
			coinAge += i.Num * curCoinAge
			//重新设置更新时间
			(*CoinPool)[k].Time = curTime
		}
	}
	if realDif+dif*coinAge/Minute > MaxProbably {
		realDif = MaxProbably
	} else {
		realDif += dif * coinAge / Minute
	}
	target := big.NewInt(1)               //大数,只对int64有效，其它需要先转化
	target.Lsh(target, uint(255-realDif)) //左位移，相当于<<,uint基于架构的类型
	fmt.Println("target:",target)
	fmt.Println("realDif:",realDif)
	nonce := 0
	for ; nonce < INT64_MAX; nonce++ {
		/**if nonce%10000==0{
			fmt.Println("nonce:",nonce)
		}**/
		check := bytes.Join( //byte是uint8的别名
			[][]byte{
				b.PrevHash,
				[]byte(b.Data),
				IntToHex(b.Height),
				IntToHex(b.Timestamp),
				IntToHex(nonce),
			},
			[]byte{}) //二位数组转为一维数组
		hash := sha256.Sum256(check)
		var hashint big.Int
		hashint.SetBytes(hash[:])
		if hashint.Cmp(target) == -1 {
			return hash[:], nonce, 255 - realDif
		}
	}
	return []byte(""), -1, 255 - realDif
}

func IntToHex(num int) []byte {
	n:=int64(num)
	buff := new(bytes.Buffer)                        //创建Buffer缓冲器
	err := binary.Write(buff, binary.BigEndian, n) //数字转化为byte
	if err != nil {                                  //如果等于nil说明运行正常
		panic(err) //手动触发宕机，输出错误信息到堆栈
	}
	return buff.Bytes()
}

//输出区块链
func Print(bc *BlockChain) {
	for _, i := range bc.Blocks {
		fmt.Printf("PrevHash: %x\n", i.PrevHash)
		fmt.Printf("Hash: %x\n", i.Hash)
		fmt.Println("Block's Data: ", i.Data)
		fmt.Println("Current Height: ", i.Height)
		fmt.Println("Timestamp: ", i.Timestamp)
		fmt.Println("Nonce: ", i.Nonce)
		fmt.Println("Dif: ", i.Dif)
	}
}
