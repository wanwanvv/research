package Coin

import(
    "fmt"
)

type Coin struct {
	Time    int
	Num     int
	Address string
}

//生成币池
func GenerateCoinPool(n int) *[]Coin {
	var CoinPool []Coin = make([]Coin, n)
	return &CoinPool
}

//output the coinpool
func PrintCoinPool(CoinPool *[]Coin) {
  for _,i:=range (*CoinPool){
    fmt.Println("Coin's Num: ",i.Num)
    fmt.Println("Coin's Time: ",i.Time)
    fmt.Println("Coin's Owner: ",i.Address)
  }
}
