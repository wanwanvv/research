#include <iostream>
#include <fstream>
#include "./command/buildCache.h"

void exit_with_help(){
  std::cout<<"Command Usage: (the first parameter specifies the procedure be executed)"<<std::endl;
  std::cout<<"-------------------------"<<std::endl;
  return;
}

int main(int argc,char* argv[])
{
  int opt='m';
  if(argc>1){
    switch(argv[1][1]){
      case 'c'://compute all shortest paths and query it
	      opt='c';
	      break;
      case 'x':
	      opt='x';
	      break;
      case 'q':
	      opt='q';
	      break;
      default:
	      exit_with_help();
	      break;
    }
  }
  if(argc==1) exit_with_help();
  int result=0;
  Command* m = NULL;
  switch(opt){
    case 'c':
      m = new command::BuildCache();
      break;
    default:
      break;
  }
  if(m!=NULL){
    result=m->main(argc,argv);
    delete m;
  }else{
    exit_with_help();
  }
  return result;
  return 0;
}
