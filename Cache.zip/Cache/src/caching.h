#ifndef _SP_CACHING_
#define  _SP_CACHING_

#include <iostream>
#include <vector>
#include <map>
#include <set>
#include "../const.h"

using namespace std;

class SPCaching{
    public:
        unsigned int budget;//the bounded budget foe cache (num of nodes)
        vector<path> _cachePaths; //store the cache paths
        vector<int>  _cacheIndex;//store the cache paths index
        vector<vector<int> > _invertedList;//fetch the cache paths index containing vi
        unsigned int _numOfCacheVertices;
        /*
         *@description: deconstructions
         *@author: wanjingyi
         *@date: 2020-12-25
        */
       ~SPCaching(){
           _cachePaths.clear();
           _cacheIndex.clear();
           _invertedList.clear();
       }

         /*
         *@description: constructions
         *@author: wanjingyi
         *@date: 2020-12-25
        */
       SPCaching(int budgetSize){
           budget=budgetSize;
           _cachePaths.clear();
           _cacheIndex.clear();
           _invertedList.clear();
       }

       /*
        *@description: generate inverted list
        *@author: wanjingyi
        *@date: 2020-12-25
       */

      void generate_invertedList(){
          set<NodeID> cache_vertices;
          //get the nodes in cache
          for(int i=0;i<_cachePaths.size();++i){
              path cache_path=_cachePaths[i];
              for(int j=0;j<cache_path.size();++j){
                  cache_vertices.insert(cache_path[j].first);
              }
          }
          _numOfCacheVertices=cache_vertices.size();
            _invertedList.resize(_numOfCacheVertices);
            for(int i=0;i<_numOfCacheVertices;++i){
                _invertedList[i]
            }
      }
};



#endif //_COMMAND_APCACHING_PROCESSING_