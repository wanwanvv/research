#pragma once

#ifndef TIME_UTIL_H
#define TIME_UTIL_H

#include <sys/time.h>
#include<map>

namespace time_util {

	//double GetCurrentTimeSec() { return 0; }
	
	double GetCurrentTimeSec() {
		struct timeval tv;
		gettimeofday(&tv, NULL);
		return tv.tv_sec + tv.tv_usec * 1e-6;
	}
	
}
#endif