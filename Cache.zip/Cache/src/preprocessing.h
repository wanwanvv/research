#pragma once
#ifndef PREPROCESSING_H_
#define PREPROCESSING_H_

#include <iostream>
#include <fstream>
#include <queue>
#include <set>
#include<math.h>
#include <omp.h>
#include <map>
#include <vector>
#include <algorithm>
#include <sstream>
#include "../command.h"
#include "../const.h"
#include "../src/graph.h"
#include "../src/heap.h"

#define numOfVertices SP_Constants::numOfVertices
#define numOfEdges SP_Constants::numOfEdges
#define INF_WEIGHT SP_Constants::INF_WEIGHT
#define WEIGHTED_FLAG SP_Constants::WEIGHTED_FLAG  
#define DIRECTED_FLAG SP_Constants::DIRECTED_FLAG


class Preprocessing {
    public:
        unsigned int _numOfSPs;
        long long _total_query_time;
        vector<vector<EdgeWeight> > SP_distances; //store the distances by index(s,t)
        vector<path> SP_paths;//store the shortest paths of graph
        vector<vector<int> > SP_index;//fetch the shotest path by (s,t)
        vector<vector<unsigned int> > Query_time;//store the query time of each stPair
        void exit_with_help(){
            std::cout<<"Usage:"<<std::endl;
            std::cout<<"-------------------------------------------------------------------"<<std::endl;
        }

        /*
            *@description: constructions
            *@author: wanjingyi
            *@date: 2020-12-24
        */
        Preprocessing(){}

        Preprocessing(WGraph &wgraph,char* debugDirName, char* queryLogFileName)//weighted_undirected_graph
        {
            std::cout<<"***************init iterms begins**************"<<endl;
            initIterms();
            std::cout<<"***************init iterms finished**************"<<endl;
            std::cout<<"***************omp dijkstra begins**************"<<endl;
            compute_all_SP_paths_undirected_weighted(wgraph);
            std::cout<<"***************omp dijkstra finished**************"<<endl;
            std::cout<<"***************debug output begins**************"<<endl;
            debug_write_to_file(debugDirName);
            std::cout<<"***************debug output finished**************"<<endl;
            std::cout<<"***************read and proprecss query log begins**************"<<endl;
            
            std::cout<<"***************read and proprecss query log finished**************"<<endl;
        }

        ~Preprocessing(){
            SP_distances.clear();
            SP_paths.clear();
            SP_index.clear();
            Query_time.clear();
        }

        /*
            *@description: compute all SP paths with omp
            *@author: wanjingyi
            *@date: 2020-12-24
        */
        void compute_all_SP_paths_undirected_weighted(WGraph &wgraph){
            int num_threads = 10;
            //variables
            vector<benchmark::heap<2, EdgeWeight, NodeID> > pqueue(num_threads, benchmark::heap<2, EdgeWeight, NodeID>(numOfVertices) );
            vector<vector<bool> > vis(num_threads, vector<bool>(numOfVertices)); //vis for omp
            vector<vector<EdgeWeight> > distances(num_threads, vector<EdgeWeight>(numOfVertices, INF_WEIGHT));
            vector<vector<path> >  paths(num_threads, vector<path>(numOfVertices));
            omp_set_num_threads(num_threads);//设置线程数
            #pragma omp parallel for schedule(dynamic)
            for (NodeID v = numOfVertices - 1; v > 0; --v) {
                source_Dijkstra(v,wgraph,vis[omp_get_thread_num()],pqueue[omp_get_thread_num()],distances[omp_get_thread_num()],paths[omp_get_thread_num()]);
            }
            _numOfSPs=SP_paths.size();
            std::cout<<"numofSPs = "<<_numOfSPs<<endl;
        }

    protected:

        /*
         *@description: read the query log and preprocess it
         *@author: wanjingyi
         *@date: 2020-12-24
        */
        void read_and_process_queryLog(char* queryLogFileName){
            ifstream in(queryLogFileName);
            if(!in.is_open()) std::cout<<queryLogFileName<<"cann't be opened!"<<endl;
            char line[24];
			 //read each line representing HFpoint to vector 
			 while (in.getline(line,sizeof(line)))
			 {
				 stringstream ql(line);
				 ql>>t;
				 ++i;
			 }
			 in.close();
        }

        /*
            *@description: init all iterms before computing
            *@author: wanjingyi
            *@date: 2020-12-24
        */
        void initIterms(){
            _numOfSPs=0;
            _total_query_time=0;
            SP_distances.resize(numOfVertices,vector<EdgeWeight>(numOfVertices,INF_WEIGHT));
            SP_paths.reserve(numOfVertices*numOfVertices);//reserve n*n paths
            SP_index.resize(numOfVertices,vector<int>(numOfVertices,-1));//-1 means no path
            Query_time.resize(numOfVertices,vector<unsigned int>(numOfVertices,0));
        }
        /*
        *@description: Dijkstra algorithm
        *@author: wanjingyi
        *@date: 2020-12-24
        */
        void source_Dijkstra(NodeID source,WGraph &wgraph, vector<bool>& vis, benchmark::heap<2, EdgeWeight, NodeID>& pqueue, vector<EdgeWeight>& distances, vector<path>& paths){
            pqueue.update(source,0);
            distances[source]=0;
            //paths[source].push_back(make_pair(source,0));
            NodeID u,v; EdgeWeight u_w,v_w,v_d;
            while(!pqueue.empty())
            {
                pqueue.extract_min(u,u_w);
                vis[u]=true;
                for (EdgeID eid = wgraph.vertices[u]; eid < wgraph.vertices[u + 1]; ++eid) {
                    v = wgraph.edges[eid].first;
                    v_w=wgraph.edges[eid].second;
                    v_d=distances[u]+v_w;
                    if(!vis[v]){
                        if(v_d<distances[v]){
                            distances[v]=distances[u]+v_w;
                            pqueue.update(v,v_d);
                            //store the path
                            if(u==source||paths[u].empty()){
                                paths[v].push_back(make_pair(v,v_w));
                            }else{
                                path prevPath(paths[u]);
                                prevPath.push_back(make_pair(v,v_w));
                                paths[v]=prevPath;
                            }
                        }
                    }
                }
            }
            vector<EdgeWeight> & SP_distances_source=SP_distances[source];
            vector<int> &SP_index_source=SP_index[source];
            //clear tmp list
            for(NodeID i=0;i<numOfVertices;++i){
                if(!paths[i].empty()){
                    SP_paths.push_back(paths[i]);
                    SP_index_source[i]=SP_paths.size()-1;
                }
                SP_distances_source[i]=distances[i];
                vis[i]=false;
                distances[i]=INF_WEIGHT;
                paths[i].clear();
                pqueue.clear();
            }
        }

        /*
            *@description: output debug information
            *@author: wanjingyi
            *@date: 2020-12-24
        */
        void debug_write_to_file(char* write_filename){
            string write_filename_prefix1(write_filename);
            string sp_debug_filename1=write_filename_prefix1.append("_SP1.debug");
            ofstream ofs1(sp_debug_filename1);
            for(size_t i=0;i<_numOfSPs;++i){
                for(size_t j=0;j<SP_paths[i].size();++j){
                    ofs1<<SP_paths[i][j].first<<"-"<<SP_paths[i][j].second<<" ";
                }
                ofs1<<endl;
            }
            ofs1.close();
            string write_filename_prefix(write_filename);
            string sp_debug_filename=write_filename_prefix.append("_SP.debug");
            ofstream ofs(sp_debug_filename);
            for(NodeID i=0;i<numOfVertices;++i){
                for(NodeID j=0;j<numOfVertices;++j){
                    ofs<<i<<" "<<j<<" "<<SP_distances[i][j]<<endl;
                    int sp_id=SP_index[i][j];
                    if(sp_id==-1) continue;
                    //output the path of each stPair
                    ofs<<"(";
                    std::cout<<" sp_id = "<<sp_id<<" SP_paths[sp_id].size() = "<<SP_paths[sp_id].size()<<endl;
                    for(size_t k=0;k<SP_paths[sp_id].size();++k) ofs<<SP_paths[sp_id][k].first<<"-"<<SP_paths[sp_id][k].second<<" ";
                    ofs<<")"<<endl;
                }
            }
            ofs.close();

        }

};

    #endif //#ifndef PREPROCESSING_H_