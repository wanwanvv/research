#pragma once
#ifndef PREPROCESSING_H_
#define PREPROCESSING_H_

#include <iostream>
#include <fstream>
#include <queue>
#include <set>
#include<math.h>
#include <omp.h>
#include <map>
#include <vector>
#include <algorithm>
#include <unordered_map>
#include <set>
#include <sstream>
#include "../command.h"
#include "../const.h"
#include "./graph.h"
#include "./heap.h"
#include "./caching.h"

#define numOfVertices SP_Constants::numOfVertices
#define numOfEdges SP_Constants::numOfEdges
#define INF_WEIGHT SP_Constants::INF_WEIGHT
#define WEIGHTED_FLAG SP_Constants::WEIGHTED_FLAG  
#define DIRECTED_FLAG SP_Constants::DIRECTED_FLAG

using namespace std;

class Preprocessing {
    public:
        //defined strcut for query log
        struct queryPair
        {
            int pathIndex;//the sp path index
            pair<NodeID,NodeID> stPair;//(s,t)query pair
            bool is_covered; //indicates whether been coveraged
            bool is_cached; //indicates whether been cached
            unsigned int queryTime;//store the query time in queryLog of the pair
            unsigned int len;//the length (num of nodes)
            unsigned int expense;//expense means num of hops (len-1)
            queryPair():pathIndex(-1),stPair(make_pair(0,0)),is_covered(false),is_cached(false),queryTime(0),len(INF_WEIGHT),expense(0){}
            queryPair(int index,NodeID s,NodeID t,bool f_covered,bool f_cached,unsigned int qt,unsigned int l,unsigned e):pathIndex(index),stPair(make_pair(s,t)),is_covered(f_covered),is_cached(f_cached),queryTime(qt),len(l),expense(e){}
        };

        //variables
        unsigned int _numOfSPs;
        unsigned int _numOfQuerylog;
        long long _total_query_time;
        unsigned int _max_query_time;
        unsigned int _min_query_time;
        vector<vector<EdgeWeight> > SP_distances; //store the distances by index(s,t)
        vector<path> SP_paths;//store the shortest paths of graph
        vector<vector<int> > SP_index;//fetch the shotest path by (s,t)
        vector<queryPair> _queryLog;//store the query pairs in query log

        void exit_with_help(){
            std::cout<<"Usage:"<<std::endl;
            std::cout<<"-------------------------------------------------------------------"<<std::endl;
        }

        /*
            *@description: constructions
            *@author: wanjingyi
            *@date: 2020-12-24
        */
        Preprocessing(){}

        Preprocessing(WGraph &wgraph,char* debugDirName, char* queryLogFileName,int budgetSize)//weighted_undirected_graph
        {
            std::cout<<"***************init iterms begins**************"<<endl;
            initIterms();
            std::cout<<"***************init iterms finished**************"<<endl;
            std::cout<<"***************omp dijkstra begins**************"<<endl;
            compute_all_SP_paths_undirected_weighted(wgraph);
            std::cout<<"***************omp dijkstra finished**************"<<endl;
            std::cout<<"***************debug output begins**************"<<endl;
            debug_write_to_file(debugDirName);
            std::cout<<"***************debug output finished**************"<<endl;
            std::cout<<"***************read and proprecss query log begins**************"<<endl;
            read_and_process_queryLog(queryLogFileName);
            std::cout<<"***************read and proprecss query log finished**************"<<endl;
            std::cout<<"***************select  begins**************"<<endl;
            SPCaching spcache(budgetSize);

            std::cout<<"***************read and proprecss query log finished**************"<<endl;
        }

        ~Preprocessing(){
            SP_distances.clear();
            SP_paths.clear();
            SP_index.clear();
            _queryLog.clear();
        }

        /*
            *@description: compute all SP paths with omp
            *@author: wanjingyi
            *@date: 2020-12-24
        */
        void compute_all_SP_paths_undirected_weighted(WGraph &wgraph){
            int num_threads = 10;
            //variables
            vector<benchmark::heap<2, EdgeWeight, NodeID> > pqueue(num_threads, benchmark::heap<2, EdgeWeight, NodeID>(numOfVertices) );
            vector<vector<bool> > vis(num_threads, vector<bool>(numOfVertices)); //vis for omp
            vector<vector<EdgeWeight> > distances(num_threads, vector<EdgeWeight>(numOfVertices, INF_WEIGHT));
            vector<vector<path> >  paths(num_threads, vector<path>(numOfVertices));
            omp_set_num_threads(num_threads);//设置线程数
            #pragma omp parallel for schedule(dynamic)
            for (NodeID v = numOfVertices - 1; v > 0; --v) {
                source_Dijkstra(v,wgraph,vis[omp_get_thread_num()],pqueue[omp_get_thread_num()],distances[omp_get_thread_num()],paths[omp_get_thread_num()]);
            }
            _numOfSPs=SP_paths.size();
            std::cout<<"numofSPs = "<<_numOfSPs<<endl;
        }

    protected:

        /*
         *@description: place paths into cache by greedy algorithm
         *@author: wanjingyi
         *@date: 2020-12-25
        */
        void greedy_cache_algorithm(vector<path>& cachePaths,vector<int> & cacheIndex,unsigned int budget){
            benchmark::heap<2, double, int> max_queue(_numOfQuerylog);
            unsigned int curr_budget=0;
            vector<set<NodeID> > vertices_set(_numOfQuerylog);
            set<int> cached_st_set;
            vector<set<int>> path_st_set(_numOfQuerylog);
            //first round:compute initial benefits of all queryPairs
            for(int i=0;i<_numOfQuerylog;++i){
                double result=0;
                queryPair curr_query_pair=_queryLog[i];
                int path_index=curr_query_pair.pathIndex;
                //add path-contaiming vertices into set
                vertices_set[i].insert(curr_query_pair.stPair.first);
                for(int j=0;j<SP_paths[path_index].size();++j){
                    vertices_set[i].insert(SP_paths[path_index][j].first);
                }
                for(int j=0;j<_numOfQuerylog;++j){
                    NodeID s=_queryLog[j].stPair.first;
                    NodeID t=_queryLog[j].stPair.second;
                    //can cover s-t query
                    if(vertices_set[i].find(s)!=vertices_set[i].end()&&vertices_set[i].find(t)!=vertices_set[i].end()){
                        path_st_set[i].insert(j);
                        result+=(double)_queryLog[j].expense*(double)_queryLog[j].queryTime;
                    }
                }
                result/=(double)curr_query_pair.len;
                max_queue.update(i,-result);
            }

            //place sp-paths into cache
            while (!max_queue.empty()&&curr_budget<=budget)
            {
                int qp_index;
                double qp_benefit;
                max_queue.extract_min(qp_index,qp_benefit);
                qp_benefit=-qp_benefit;
                //update the benefit
                double result=0;
                queryPair curr_query_pair=_queryLog[qp_index];
                set<int>::iterator iter;
                for(iter=cached_st_set.begin ();iter!=cached_st_set.end ();iter++)
                {
                     if(path_st_set[qp_index].find(*iter)!=path_st_set[qp_index].end()){
                         path_st_set[qp_index].erase(*iter);//remove the st_path which has been covered by cache
                     }
                }
                for(iter=path_st_set[qp_index].begin();iter!=path_st_set[qp_index].end();iter++)
                {
                    int i=*iter;
                    result+=(double)curr_query_pair.expense*(double)curr_query_pair.queryTime;
                }
                result/=curr_query_pair.len;
                int next_top_index=max_queue.top_value();
                double next_top_benefit=max_queue.top();
                next_top_benefit=-next_top_benefit;
                if(result>=next_top_benefit){
                    if(curr_query_pair.len<=budget-curr_budget){
                        //place the path into cache
                        curr_budget+=curr_query_pair.len;
                        cacheIndex.push_back(qp_index);
                        cachePaths.push_back(SP_paths[curr_query_pair.pathIndex]);
                    }
                }else{
                    max_queue.update(qp_index,result);
                }
            }
            //output the cache result
            std::cout<<"num of cache paths ="<<cachePaths.size()<<endl;
            std::cout<<"curr_budget = "<<curr_budget<<endl;
        }

        /*
         *@description: read the query log and preprocess it
         *@author: wanjingyi
         *@return: total_query_time
         *@date: 2020-12-24
        */
        void read_and_process_queryLog(char* queryLogFileName){
            ifstream in(queryLogFileName);
            if(!in.is_open()) std::cout<<queryLogFileName<<"cann't be opened!"<<endl;
            char line[24];
            NodeID s,t;//start and end node 
            unsigned int x;//query_time
			 //read each line representing HFpoint to vector 
			 while (in.getline(line,sizeof(line)))
			 {
				 stringstream ql(line);
				 ql>>s>>t>>x;
				 _total_query_time+=x;
                 int index=SP_index[s][t];
                 unsigned int siz=SP_paths[index].size();
                 _queryLog.push_back(queryPair(index,s,t,false,false,x,siz+1,siz));
			 }
			 in.close();
             _numOfQuerylog=_queryLog.size();
             std::cout<<"total_query_time = "<<_total_query_time<<endl;
             std::cout<<"_numOfQuerylog = "<<_numOfQuerylog<<endl;//printf num of query stPairs
        }
        /*
            *@description: init all iterms before computing
            *@author: wanjingyi
            *@date: 2020-12-24
        */
        void initIterms(){
            _numOfSPs=0;
            SP_distances.resize(numOfVertices,vector<EdgeWeight>(numOfVertices,INF_WEIGHT));
            SP_paths.reserve(numOfVertices*numOfVertices);//reserve n*n paths
            SP_index.resize(numOfVertices,vector<int>(numOfVertices,-1));//-1 means no path
            _queryLog.clear();
            _total_query_time=0;
            _max_query_time=0;
            _min_query_time=INF_WEIGHT;
            _numOfQuerylog=0;
        }
        /*
        *@description: Dijkstra algorithm
        *@author: wanjingyi
        *@date: 2020-12-24
        */
        void source_Dijkstra(NodeID source,WGraph &wgraph, vector<bool>& vis, benchmark::heap<2, EdgeWeight, NodeID>& pqueue, vector<EdgeWeight>& distances, vector<path>& paths){
            pqueue.update(source,0);
            distances[source]=0;
            //paths[source].push_back(make_pair(source,0));
            NodeID u,v; EdgeWeight u_w,v_w,v_d;
            while(!pqueue.empty())
            {
                pqueue.extract_min(u,u_w);
                vis[u]=true;
                for (EdgeID eid = wgraph.vertices[u]; eid < wgraph.vertices[u + 1]; ++eid) {
                    v = wgraph.edges[eid].first;
                    v_w=wgraph.edges[eid].second;
                    v_d=distances[u]+v_w;
                    if(!vis[v]){
                        if(v_d<distances[v]){
                            distances[v]=distances[u]+v_w;
                            pqueue.update(v,v_d);
                            //store the path
                            if(u==source||paths[u].empty()){
                                paths[v].push_back(make_pair(v,v_w));
                            }else{
                                path prevPath(paths[u]);
                                prevPath.push_back(make_pair(v,v_w));
                                paths[v]=prevPath;
                            }
                        }
                    }
                }
            }
            vector<EdgeWeight> & SP_distances_source=SP_distances[source];
            vector<int> &SP_index_source=SP_index[source];
            //clear tmp list
            for(NodeID i=0;i<numOfVertices;++i){
                if(!paths[i].empty()){
                    SP_paths.push_back(paths[i]);
                    SP_index_source[i]=SP_paths.size()-1;
                }
                SP_distances_source[i]=distances[i];
                vis[i]=false;
                distances[i]=INF_WEIGHT;
                paths[i].clear();
                pqueue.clear();
            }
        }

        /*
            *@description: output debug information
            *@author: wanjingyi
            *@date: 2020-12-24
        */
        void debug_write_to_file(char* write_filename){
            string write_filename_prefix1(write_filename);
            string sp_debug_filename1=write_filename_prefix1.append("_SP1.debug");
            ofstream ofs1(sp_debug_filename1);
            for(size_t i=0;i<_numOfSPs;++i){
                for(size_t j=0;j<SP_paths[i].size();++j){
                    ofs1<<SP_paths[i][j].first<<"-"<<SP_paths[i][j].second<<" ";
                }
                ofs1<<endl;
            }
            ofs1.close();
            string write_filename_prefix(write_filename);
            string sp_debug_filename=write_filename_prefix.append("_SP.debug");
            ofstream ofs(sp_debug_filename);
            for(NodeID i=0;i<numOfVertices;++i){
                for(NodeID j=0;j<numOfVertices;++j){
                    ofs<<i<<" "<<j<<" "<<SP_distances[i][j]<<endl;
                    int sp_id=SP_index[i][j];
                    if(sp_id==-1) continue;
                    //output the path of each stPair
                    ofs<<"(";
                    std::cout<<" sp_id = "<<sp_id<<" SP_paths[sp_id].size() = "<<SP_paths[sp_id].size()<<endl;
                    for(size_t k=0;k<SP_paths[sp_id].size();++k) ofs<<SP_paths[sp_id][k].first<<"-"<<SP_paths[sp_id][k].second<<" ";
                    ofs<<")"<<endl;
                }
            }
            ofs.close();

        }

};

    #endif //#ifndef PREPROCESSING_H_