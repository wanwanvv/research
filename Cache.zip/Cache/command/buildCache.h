#pragma once
#ifndef _COMMAND_BUILD_CACHE_
#define _COMMAND_BUILD_CACHE_

#include <iostream>
#include <fstream>
#include <cstring>
#include <map>
#include "../command.h"
#include "../const.h"
#include "../src/graph.h"
#include "../src/preprocessing.h"
#include "../src/time_util.h"

using namespace time_util; 

#define numOfVertices SP_Constants::numOfVertices
#define numOfEdges SP_Constants::numOfEdges
#define INF_WEIGHT SP_Constants::INF_WEIGHT
#define WEIGHTED_FLAG SP_Constants::WEIGHTED_FLAG  
#define DIRECTED_FLAG SP_Constants::DIRECTED_FLAG

namespace command{
    class BuildCache: public Command{
        public:
            void exit_with_help(){
                printf("Usage:\n");
                printf("\t... \n");//./cache_run -c -d 0 -w 1 -g  ../dataset/test.graph -t ../debug/test -l ../dataset/query.log -b 
                printf("Parameter explanation:\n");
                printf("Examples:\n");
            }

            int main(int argc,char* argv[]){
                char graphFileName[255] = "";
                char debugDirName[255] = "";
                char queryLogFileName[255] = "";
                int t_directed_flag = 0;
                int t_weighted_flag = 0;
                int budget_size= 0;
                // if(argc < 14) /// num of command line parameters
                //     exit_with_help();
                for(int i = 2; i < argc; i++){
                    if(argv[i][0] != '-') break;
                    if(++i >= argc) exit_with_help();
                    switch (argv[i-1][1]){
                        case 'g':
                            strcpy(graphFileName,argv[i]);
                            cout<<" graphFileName = "<<graphFileName<<endl;
                            break;
                        case 'd':
                            t_directed_flag = atoi(argv[i]);
                            break;
                        case 'w':
                            t_weighted_flag = atoi(argv[i]);
                            break;
                        case 't':
                            strcpy(debugDirName,argv[i]);
                            cout<<"debugDirName = "<<debugDirName<<endl;
                            break;
                        case 'l':
                            strcpy(queryLogFileName,argv[i]);
                            cout<<"queryLogFileName = "<<queryLogFileName<<endl;
                            break;
                        case 'b':
                            budget_size = atoi(argv[i]);
                            break;
                        default:
                            exit_with_help();
                    }
                }

                if (t_directed_flag == 1) DIRECTED_FLAG = true;
                if (t_weighted_flag == 1) WEIGHTED_FLAG = true;
                
                Graph graph;
                WGraph wgraph;
                if(WEIGHTED_FLAG == true){
                    wgraph.load_graph(graphFileName);
                }else{
                    graph.load_graph(graphFileName);
                }
                cout << numOfVertices << " nodes and " << numOfEdges << " arcs " << endl;
                if (numOfVertices == 0 || numOfEdges == 0){
                    cout << "Corruptted graph file" << endl;
                    return 0;
                }
                double _labeling_time = GetCurrentTimeSec();
                Preprocessing preprocessing(wgraph,debugDirName,queryLogFileName,budget_size);
                _labeling_time = GetCurrentTimeSec() - _labeling_time;
                return 0;
            }
    };
}

#endif //_COMMAND_BUILD_CACHE_