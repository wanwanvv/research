#pragma once
#ifndef CONST_H_
#define CONST_H_
#include<cstdint> 
#include <limits>
#include <vector>
#include <map>

using namespace std;

//typedef unsigned int NodeID;
typedef int NodeID;
typedef long long EdgeID;
//typedef double EdgeWeight;
typedef  int EdgeWeight;
//define weight edge
typedef pair<NodeID, EdgeWeight> NodeEdgeWeightPair;
//define path type
typedef vector<NodeEdgeWeightPair> path;

namespace SP_Constants{
  bool DIRECTED_FLAG = false;
  bool WEIGHTED_FLAG = false;
  int numOfVertices = 0;
  int numOfEdges = 0;
  const extern int INF_WEIGHT = std::numeric_limits<int>::max() / 3;
}


#endif CONST_H_
